# ai-hw1-basicneuralnet
Implementation of a basic neural network with a single hidden layer
